<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ConfigAdminController extends Controller
{
	public function usd_to_inr()
	{
		echo 'Success';
	}
   
}
