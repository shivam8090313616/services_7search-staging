<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ConfigUserController extends Controller
{
    public function usd_to_inr()
    {
        
        echo 'successfully'; exit();
    }
}
