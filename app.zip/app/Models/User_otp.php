<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class User_otp extends Model
{
    protected $table='user_otps';
    use HasFactory;
}
